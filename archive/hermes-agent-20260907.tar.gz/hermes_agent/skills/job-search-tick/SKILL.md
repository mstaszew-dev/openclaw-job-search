---
name: job-search-tick
description: One PL job per tick - pick, dedupe, apply, record
version: 1.1.0
platforms: [macos]
metadata:
  hermes:
    tags: [job-search, career, automation]
---

# Job-Search Tick

## When to Use

Run once per campaign tick (cron or manual) to apply to exactly ONE job and
record it. Never run twice in a row without a recorded outcome.

## Procedure

1. `campaign_status` tool: read progress and recent applications (dedupe
   context).
2. Read `AGENT_TICK.md` and `CONTEXT.md` in the campaign dir
   (`/Users/mst/Downloads/job-search/job-apply`).
3. Pick ONE matching job using the targeting rules below. Honor the
   DIRECTOR SKIP LIST if the tick prompt contains one.
4. Dedupe: rag search over past applications (rag MCP tools) plus Gmail
   (in:sent OR in:inbox, newer_than:60d, company name). One company once.
5. Apply with the playwright MCP tools (existing Chrome CDP at
   http://127.0.0.1:9222; never launch or close Chrome). Verify the portal
   confirmation (thank-you page or text) before recording.
6. Record via the `record_submission` tool immediately after confirmation,
   with evidence of the confirmation in the record.
7. End the turn. ONE job per tick, no more.

## Pitfalls

- Never edit tracker.json directly; only `record_submission` may write it
  (via update_tracker.py).
- Never call score_candidate.py or check_dupe.py (retired automation).
- Do not apply to skip-listed companies or to companies applied to in the
  last 60 days.
- Temp scripts go in /tmp/, never the campaign dir.
- A submission without portal confirmation evidence does not count.

## Targeting rules

- Targets: Java/Kotlin/Spring, PHP/Laravel, Node/React. Roles involving TDD,
  code reviews, CI/CD (Jenkins, GitHub Actions) are in scope. Skip: ABAP,
  Salesforce, C/C++, .NET, ML/data, DevOps/SRE-only.
- Seniority: ALL levels accepted (junior through senior). Skip only:
  team-lead/manager/architect/director/head/VP.
- Region: PL only - Polish market only. Every tick targets Poland - do not
  apply to roles outside Poland.
- PL: fully remote ONLY (NoFluffJobs / JustJoin.it / theProtocol.it),
  B2B >= 15 000 PLN net+VAT/month (skip when the listing shows a lower B2B
  rate).
- CV: cv/michael-staszewski-cv-pl.pdf. PL forms: phone +48790775407,
  location Biała Parcela, woj. łódzkie, coverNotePl / plB2bNotePl from
  applicant.json; NEVER mention relocation or Israel on PL forms.
- IDENTITY on forms (use EXACTLY these values; never invent, guess, or vary):
  name Michał Staszewski; email mst.rocking@gmail.com (the ONLY email - never
  any other address); phone +48790775407; location Biała Parcela, woj.
  łódzkie. The tick prompt carries the same IDENTITY block.
- Freelance: include freelance, contract, part-time, and fixed-term B2B in
  the Polish market.
