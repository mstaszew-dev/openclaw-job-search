# Hermes job-search campaign agent

Hermes-native replacement for `campaign_agent/`: the agent loop, inference
(msrouter), and MCP (playwright CDP + rag) are provided by Hermes; this
package adds the campaign domain.

## Operating policy (user preference, 2026-08-26)

NO Hermes background processes on this machine: no gateway, no dashboard
server, no cron, no supervised launcher. The bot runs ONLY inside the Hermes
desktop app, started manually by the user:

    open ~/.hermes/hermes-agent/apps/desktop/release/mac-arm64/Hermes.app

(then pick the `jobhunter` profile and chat). Do not run `hermes gateway`,
`hermes dashboard`, `install.sh --enable-cron`, or `job-search-agent-hermes`
unless the user explicitly asks. The standalone Python agent keeps campaign
ownership; the Hermes runner's cross-agent guard enforces this regardless.

## Layout

- `src/jobapps/` - Hermes plugin: `campaign_status`, `record_submission`.
- `src/jobhermes/` - tick runner: config, prompt, tick context, retry loop,
  anti-gaming validation (a tick succeeds only when tracker.submitted grew).
- `skills/job-search-tick/` - tick procedure + targeting policy skill.
- `install/` - jobhunter profile installer (plugin + skill + provider
  config); cron registration is opt-in via `--enable-cron`.
- `tests/` - offline pytest suite; coverage gate 98% (line+branch) enforced on every run
  (currently 100%).

## Install (no cron, no live side effects)

```zsh
zsh install/install.sh
```

Creates the `jobhunter` Hermes profile, symlinks the plugin and skill into
it, writes the managed `config.yaml` (msrouter provider, playwright + rag
MCP servers), and validates the plugin with `hermes plugins doctor`.

## Manual tick

```zsh
PYTHONPATH=src python3 -m jobhermes --once      # one tick (runs REAL agent)
PYTHONPATH=src python3 -m jobhermes --dry-run   # print the tick prompt only
PYTHONPATH=src python3 -m jobhermes --loop      # keep ticking with backoff
```

`--once` is the default mode (flag optional). Exit codes: 0 success or
campaign complete, 1 attempts exhausted / loop failure bound / hermes exit
126-127 / tracker unreadable, 2 campaign dir missing, 3 another jobhermes
instance holds the tick lock. A corrupt tracker at tick start refuses to
launch hermes at all (no oracle, no applications). `--loop` stops after
`OUTER_MAX_FAILS` consecutive failed ticks, and a lockfile
(`state/jobhermes.lock`) prevents cron and the supervised launcher from
ticking simultaneously.

## Talk to it in the Hermes UI (bot)

```zsh
hermes dashboard        # opens http://127.0.0.1:9119
```

Pick `jobhunter` in the sidebar profile switcher (or open
`http://127.0.0.1:9119/chat?profile=jobhunter`). The Chat tab runs a live
session with this profile's persona (SOUL.md), plugin tools, skills, memory,
and msrouter model. Zero-token slash shortcuts are wired:

- `/campaign-status` - progress straight from tracker.json
- `/last-tick` - the previous tick's summary
- `/prompt-preview` - the exact prompt the next scheduled tick would send

Asking the bot to "run a tick" applies to exactly ONE job with full dedupe
and confirmed-evidence recording, then stops. Install seeds the profile's
`memories/MEMORY.md` once (never overwrites Hermes-managed notes). Screenshot:
`docs/jobhunter-bot-dashboard.png`.

## Enable the 30-minute scheduler (starts REAL applications)

```zsh
zsh install/install.sh --enable-cron
```

The installer writes a wrapper to `~/.hermes/scripts/job-search-tick.sh`
(hermes cron `--script` takes a script path) and registers the job with
`--no-agent` so the tick runner owns validation and retries.

## Continuous mode + supervision (Director-style)

`install/job-search-agent-hermes` mirrors the Python agent's supervised
launcher contract: it stays alive as a zsh parent running
`python -m jobhermes --loop`, so a pgrep-based supervisor can watch it.
Point the Director at this script instead of `/Users/mst/bin/job-search-agent`
to cut over. Starting it begins REAL applications.

## Cutover from campaign_agent

- The runner inherits the Python agent's last tick summary on the first run
  (falls back to `campaign_agent/state/tick-context.md`; override with
  `LEGACY_TICK_CONTEXT_PATH`). Hermes-owned state then takes over at
  `hermes_agent/state/tick-context.md`.
- The managed profile config ships `plugins.enabled: [jobapps]`. Without that
  block the plugin loads but its tools never register - keep it if you edit
  the template.
- `campaign_agent/` remains untouched as fallback during the soak period;
  only one of the two agents may run at a time (they share Chrome CDP and
  tracker). This is enforced: every Hermes tick first checks for the
  standalone agent (`pgrep` for `campaign_agent.main` / `bin/job-search-agent`)
  and skips with a logged `python_agent_active` outcome (exit 0) while it
  runs. Stop the Python agent before expecting Hermes ticks to apply.

## Configuration

Defaults < `~/.campaign-agent/director-overrides.env` < environment.
Env keys: `CAMPAIGN_DIR`, `HERMES_BIN`, `HERMES_PROFILE`,
`INNER_MAX_FAILS` (5), `INNER_SLEEP` (10), `OUTER_BACKOFF` (60),
`OUTER_MAX_FAILS` (12),
`SUBPROCESS_TIMEOUT` (2400; also the wall-clock budget per hermes attempt
since hermes v0.20.5 removed `--run-budget`/`--max-turns`),
`PORTAL_SKIP_<Company>=1` (skip list). The
director note is read from `~/.campaign-agent/director-prompt-overrides.md`.
The per-attempt turn limit is `agent.max_turns` in the hermes profile config
(`install/config.template.yaml` writes 200); hermes v0.20.5 has no CLI flag
for it.

The jobapps plugin honors `JOBSEARCH_CAMPAIGN_DIR` and
`JOBSEARCH_TRACKER_PATH` (separate from the runner's `CAMPAIGN_DIR`). Its
`tracker_path`/`campaign_dir` tool arguments are ignored unless
`JOBSEARCH_ALLOW_OVERRIDES=1` is set (prompt-injection guard; tests set it).

CI (GitHub Actions, `.github/workflows/hermes-agent-ci.yml`): ruff + mypy
strict + pytest with the 98% line+branch coverage gate on every push/PR touching
`hermes_agent/`.

## Tests

```zsh
python3 -m venv .venv
.venv/bin/pip install -e ".[dev]"
.venv/bin/ruff check src tests && .venv/bin/mypy && .venv/bin/python -m pytest
```

The `-m jobhermes` subprocess test requires the package installed (the pip
install above), since pytest's `pythonpath=src` does not reach subprocesses.

## Old-to-new mapping

| campaign_agent (Python loop) | hermes_agent |
|---|---|
| `llm.py` (msrouter client) | Hermes provider `msrouter` (profile config) |
| `run_agent_turn` inner loop | Hermes agent (`hermes -z` one-shot) |
| `playwright_mcp.py` / `rag_mcp.py` | profile `mcp_servers` (playwright, rag) |
| `main.py` outer loop + anti-gaming | `jobhermes.runner.run_tick` (tracker-delta rule) |
| `prompt.py` | `jobhermes.prompt` (IL+PL policy pinned by tests) |
| `session.py` TickContext | `jobhermes.tick_context` (atomic writes) |
| `tracker.py` | `jobapps.tracker` |
| exec `update_tracker.py submitted` | `jobapps` tool `record_submission` |
| Director supervision | unchanged (pgrep on the launcher) or Hermes cron (`--enable-cron`); the tick lock keeps them exclusive |

Spec: `docs/superpowers/specs/2026-08-24-hermes-agent-port-design.md`.
Plan: `docs/superpowers/plans/2026-08-24-hermes-agent-port.md`.
