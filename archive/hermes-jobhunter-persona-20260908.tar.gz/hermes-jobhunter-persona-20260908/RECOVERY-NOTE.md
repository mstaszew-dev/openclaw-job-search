# Hermes jobhunter persona - recovery note (2026-09-08)

## What happened

The installed jobhunter persona at `~/.hermes/profiles/jobhunter/` was deleted
outright on 2026-09-08 during the hermes retirement cleanup, while the hermes
SOURCE was archived (`hermes-agent-20260907.tar.gz`). It should have been
archived the same way. This archive is the best-faith recovery.

## What was in the deleted directory

`~/.hermes/profiles/jobhunter/` contained: `SOUL.md`, `profile.yaml`,
`memories/MEMORY.md` (the persona definition, updated to PL-only on
2026-09-07), plus hermes CLI runtime state (`state.db` ~13MB, `sessions/`,
`logs/`, `cron/`, `skills/` (20 entries), `config.yaml`, `auth.json`, caches).

## What survived, and where

- The persona DEFINITION seeds: `install-seeds/` in this archive (extracted
  unchanged from `hermes-agent-20260907.tar.gz`):
  - `profile-soul.md` - SOUL seed
  - `profile-memory-seed.md` - memory seed
  - `config.template.yaml` - config template
- The PL-only policy text that was applied to the installed persona on
  2026-09-07 exists in the same source archive:
  - `hermes_agent/src/jobhermes/prompt.py` (identity block + task rules)
  - `hermes_agent/skills/job-search-tick/SKILL.md`
- No secrets were archived (none survived; `auth.json`/`.env` were deleted
  with the directory, which is the correct outcome for credentials).

## What is unrecoverable

The exact installed bytes of `SOUL.md` / `profile.yaml` / `memories/MEMORY.md`
(the seeds plus the 2026-09-07 PL-only edits applied in place), and ALL runtime
state: `state.db`, `sessions/`, `logs/`, `cron/`, the 20 installed skills,
`projects.db`. No APFS snapshot or Time Machine backup contained them.

A regenerated PL-only persona can be rebuilt from `install-seeds/` plus the
PL-only policy sources listed above, but it would be a reconstruction, not
the original.

## Policy going forward

Anything deleted during a retirement/cleanup gets archived first (tar.gz in
this `archive/` directory), credentials excluded, then removed from disk.
